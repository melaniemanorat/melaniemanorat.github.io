import numpy as np
import matplotlib.pyplot as plt

def compare():
    # Get the directory name for data files
    import os.path
    directory = os.path.dirname(os.path.abspath(__file__))
    # Build an absolute filename from directory + filename
    file1 = os.path.join(directory, 'marijuana_gross_sales.csv')
    data1 = open(file1,'r')
    data01 = data1.readlines()
    
    # This is the second data file
    file2 = os.path.join(directory, 'qfr_tabs_f.csv')
    data2 = open(file2, 'r')
    data02 = data2.readlines()
    
    # Marijuana Data
    marisales = []
    for line in data01: 
        quarter, money = line.split(',')
        money_value = money[:-3]
        marisales.append(money_value)
    
    # Pharmaceuticals Data
    pharmsales = []
    for line in data02[2:3]: 
        item, q3_2015, q4_2015, q1_2016, q2_2016, q3_2016 = line.split(',')
        pharmsales.append(q3_2015)
        pharmsales.append(q4_2015)
        pharmsales.append(q1_2016)
        pharmsales.append(q2_2016)
        pharmsales.append(q3_2016)
     
    # Bar Graphs
    fig, ax  = plt.subplots(1, 1)
    
    objects = ('Qt.3 (2015)', 'Qt.4 (2015)', 'Qt.1(2016)', 'Qt.2(2016)', 'Qt.3(2016)')
    y_pos = np.arange(len(objects))
    plt.bar(y_pos, pharmsales, align='center', alpha=1, color = 'red')
    plt.xticks(y_pos, objects)
    plt.ylabel('Percentage of sales')
    plt.xlabel('Years (By Quarters)')
    plt.title('Pharmaceutical Sales')   
    plt.show()

    fig, ax  = plt.subplots(1, 1)
    
    objects = ('Qt.3 (2015)', 'Qt.4 (2015)', 'Qt.1(2016)', 'Qt.2(2016)', 'Qt.3(2016)')
    y_pos = np.arange(len(objects))
    plt.bar(y_pos, marisales, align='center', alpha=1, color= 'green')
    plt.xticks(y_pos, objects)
    plt.ylabel('Percentage of sales')
    plt.xlabel('Years (By Quarters)')
    plt.title('Marijuana Sales')   
    plt.show()
        
    
# Main
compare()
